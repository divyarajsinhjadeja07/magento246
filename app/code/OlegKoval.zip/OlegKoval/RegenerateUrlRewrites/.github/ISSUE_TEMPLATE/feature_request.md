---
name: "Feature Request \U0001F4A1"
about: Suggest a new idea for the project.
title: ''
labels: feature request
assignees: ''

---

## Summary

Brief explanation of the feature.

### Basic example

If the proposal involves a new or changed API, include a basic code example. Omit this section if it's not applicable.
